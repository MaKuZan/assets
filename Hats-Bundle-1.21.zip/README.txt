=====================================================
       Hats Bundle 1.21 - Ultimate Edition (79 Hats)
=====================================================

В этот бандл объединены:
1. Оригинальные 13 шляп от Larkyy
2. 55 моделей из популярного Cosmetic Hats Pack (Аниме, Игры, Классика)
3. 8 хэллоуинских и мемных масок из Head Cosmetics (Ghostface, Michael Myers, Herobrine и др.)
4. 3 тактические и реалистичные шапки из S3EED Hats (Шемаг, Бандана, Каска)

Полная адаптация под Minecraft Java 1.21, 1.21.1, 1.21.2, 1.21.3, 1.21.4+
(Paper / Purpur / Vanilla / Fabric / Forge)

[ УСТАНОВКА ]

1. Для одиночной игры / клиента:
   - Поместите 'Hats-Bundle-1.21.zip' в папку .minecraft/resourcepacks/
   - Включите ресурс-пак в Настройки -> Наборы ресурсов.

2. Для сервера (Server Resource Pack):
   - Загрузите 'Hats-Bundle-1.21.zip' на хостинг (mc-packs.net, GitHub Releases или свой web-сервер).
   - В файле server.properties укажите:
     resource-pack=https://your-host.com/Hats-Bundle-1.21.zip
     resource-pack-sha1=<SHA1_ХЭШ_АРХИВА>
   - Совместим с плагинами: ItemsAdder, Oraxen, HatCosmetics, Nexo, CustomModelData.

-----------------------------------------------------
[ СПИСОК ВСЕХ 79 ШЛЯП И ID (CustomModelData) ]
-----------------------------------------------------
  ID | Английское название              | Русское название                           | Модель
-------------------------------------------------------------------------------------------------------------------
   1 | Cat Ears Hat                     | Кошачьи ушки                               | hats:cat_ears_hat
   2 | Cowboy Hat                       | Ковбойская шляпа                           | hats:cowboy_hat
   3 | Crown Hat 1                      | Королевская корона 1                       | hats:crown_hat1
   4 | Fox Hat                          | Шапка лисы                                 | hats:fox_hat
   5 | Gentleman Hat                    | Шляпа джентльмена                          | hats:gentleman_hat
   6 | Golden Crown                     | Золотая корона                             | hats:golden_crown
   7 | Halo Hat                         | Нимб ангела                                | hats:halo_hat
   8 | Horns Hat                        | Рога демона                                | hats:horns_hat
   9 | Iron Crown                       | Железная корона                            | hats:iron_crown
  10 | Mafia Hat                        | Шляпа мафии                                | hats:mafia_hat
  11 | Pirate Hat                       | Пиратская шляпа                            | hats:pirate_hat
  12 | Santa Hat                        | Новогодняя шапка                           | hats:santa_hat
  13 | Sombrero Hat                     | Мексиканское сомбреро                      | hats:sombrero_hat
  14 | Zero Two Horns                   | Рожки Ноль Два (Zero Two)                  | hats:cosmetic_02
  15 | Graduation Cap                   | Шапочка выпускника                         | hats:cosmetic_academic
  16 | Altair Assassin Hood             | Капюшон Альтаира (Assassin's Creed)        | hats:cosmetic_altair
  17 | Aqua Hair Clip                   | Заколка Аквы (Konosuba)                    | hats:cosmetic_aqua
  18 | Head Bandage                     | Медицинский бинт на голову                 | hats:cosmetic_bandage
  19 | Hunter Hat Bloodborne            | Шляпа охотника (Bloodborne)                | hats:cosmetic_bloodborne
  20 | Bunny Ears                       | Кроличьи ушки                              | hats:cosmetic_bunny
  21 | Clown Hat & Wig                  | Клоунский парик с колпаком                 | hats:cosmetic_clown
  22 | Chef Hat                         | Поварской колпак                           | hats:cosmetic_cook
  23 | Wild West Cowboy Hat             | Ковбойская шляпа (Дикий Запад)             | hats:cosmetic_cowboy
  24 | Royal Crown of King              | Королевская корона владыки                 | hats:cosmetic_crown
  25 | Vintage Diving Helmet            | Винтажный шлем водолаза                    | hats:cosmetic_diver
  26 | Dovahkiin Iron Helmet            | Железный шлем Довакина (Skyrim)            | hats:cosmetic_dovahkiin
  27 | Deep Rock Mining Helmet          | Каска шахтёра (Deep Rock Galactic)         | hats:cosmetic_drg
  28 | Ushanka Winter Hat               | Зимняя шапка-ушанка                        | hats:cosmetic_earflaps
  29 | Elf Ears                         | Эльфийские уши                             | hats:cosmetic_elf_ears
  30 | Furina Hat                       | Шляпа Фурины (Genshin Impact)              | hats:cosmetic_furina
  31 | Post-Apocalyptic Gas Mask        | Противогаз выжившего                       | hats:cosmetic_gas_mask
  32 | Radiant Angel Halo               | Сияющий ангельский нимб                    | hats:cosmetic_halo
  33 | Festive Santa Hat                | Праздничный колпак Санты                   | hats:cosmetic_hat_new_year
  34 | Hokage Hat                       | Шляпа Хокаге (Naruto)                      | hats:cosmetic_hokage
  35 | Demon Horns (Large)              | Рога демона (Большие)                      | hats:cosmetic_horns
  36 | Hu Tao Plum Hat                  | Шляпа Ху Тао (Genshin Impact)              | hats:cosmetic_hutao
  37 | Inosuke Boar Mask                | Маска вепря Иноске (Demon Slayer)          | hats:cosmetic_inoske
  38 | Jotaro Kujo Cap                  | Кепка Джотаро Куджо (JoJo)                 | hats:cosmetic_jotaro
  39 | Kamina Sunglasses                | Очки Камины (Gurren Lagann)                | hats:cosmetic_kamina
  40 | Kanna Dragon Horns               | Рожки дракона Канны Камуи                  | hats:cosmetic_kanna
  41 | Karen Wig                        | Прическа Карен                             | hats:cosmetic_karen
  42 | Katarina Assassin Mask           | Маска Катарины                             | hats:cosmetic_katarina
  43 | Kitsune Fox Mask                 | Традиционная маска Кицунэ                  | hats:cosmetic_kitsune
  44 | Cult of the Lamb Crown           | Корона Агнца (Cult of the Lamb)            | hats:cosmetic_lamb
  45 | Luffy Straw Hat                  | Соломенная шляпа Луффи (One Piece)         | hats:cosmetic_luffy
  46 | Megumin Wizard Hat               | Шляпа Мегумин (Konosuba)                   | hats:cosmetic_megumin
  47 | Hatsune Miku Pigtails            | Хвостики Хацунэ Мику (Vocaloid)            | hats:cosmetic_miku
  48 | Mita Ribbon                      | Лента Мита                                 | hats:cosmetic_mita
  49 | Toad Mushroom Cap                | Шляпка мухомора (Тоад)                     | hats:cosmetic_mushroom
  50 | Nanachi Ears & Hat               | Ушки Наначи (Made in Abyss)                | hats:cosmetic_nanachi
  51 | Naruto Shinobi Headband          | Повязка шиноби (Naruto)                    | hats:cosmetic_naruto
  52 | Neko Cat Ears                    | Кошачьи ушки Neko (Аниме)                  | hats:cosmetic_neko
  53 | Niko Hat & Scarf                 | Шляпа Нико (OneShot)                       | hats:cosmetic_niko
  54 | Summer Panama Hat                | Летняя панама                              | hats:cosmetic_panama_hat
  55 | Captain Tricorn Hat              | Треуголка капитана пиратов                 | hats:cosmetic_pirate
  56 | REPO Operative Helmet            | Шлем оперативника R.E.P.O                  | hats:cosmetic_repo
  57 | Blue Samurai Kabuto              | Синий шлем самурая (Кабуто)                | hats:cosmetic_samurai_blue
  58 | Red Samurai Kabuto               | Красный шлем самурая (Кабуто)              | hats:cosmetic_samurai_red
  59 | Shrek Ogre Ears                  | Уши Шрека                                  | hats:cosmetic_shrek
  60 | Solaire of Astora Helmet         | Шлем Солера (Dark Souls - Praise the Sun)  | hats:cosmetic_solaire
  61 | Charro Sombrero                  | Мексиканское сомбреро Чарро                | hats:cosmetic_sombrero
  62 | Robert Speedwagon Hat            | Шляпа Роберта Спидвагона (JoJo)            | hats:cosmetic_speedwagon
  63 | Steampunk Goggles Top Hat        | Стимпанк цилиндр с очками                  | hats:cosmetic_steam
  64 | Kasane Teto Drills               | Прическа Касанэ Тэто                       | hats:cosmetic_teto
  65 | Diamond Tiara                    | Алмазная тиара принцессы                   | hats:cosmetic_tiara
  66 | Spooky Witch Hat                 | Колдовская шляпа ведьмы                    | hats:cosmetic_witch
  67 | Blooming Flower Wreath           | Венок из весенних цветов                   | hats:cosmetic_wreath
  68 | Yazawa Nico Ribbon               | Красный бант Нико Ядзавы                   | hats:cosmetic_yazawa
  69 | Ghostface Scream Mask            | Маска Призрачного лица (Крик)              | hats:c_ghostface
  70 | Michael Myers Mask               | Маска Майкла Майерса (Хэллоуин)            | hats:c_michaelmyers
  71 | Cardboard Paper Bag              | Бумажный пакет с прорезями                 | hats:c_paperbag
  72 | Rubber Plunger                   | Резиновый вантуз на голову                 | hats:c_plunger
  73 | Sniffer Snout Hat                | Шапка в форме Нюхача                       | hats:c_snifferhat
  74 | Bouncing Slime Hat               | Живой слизень на голове                    | hats:c_slime
  75 | Prop Knife Through Head          | Бутафорский нож сквозь голову              | hats:c_knife
  76 | Glowing Herobrine Mask           | Светящиеся глаза Херобрина                 | hats:c_herobrine
  77 | Shemagh Desert Keffiyeh          | Тактическая арафатка (Шемаг)               | hats:s_shemag
  78 | Biker Skull Bandana              | Байкерская бандана                         | hats:s_bandana
  79 | Architect Construction Hardhat   | Строительная каска с карандашом            | hats:s_architect

-----------------------------------------------------
[ КОМАНДЫ ДЛЯ MINECRAFT 1.21 ]
-----------------------------------------------------
1. Выдать шляпу в руку (замените X на ID от 1 до 79):
   /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=X]

2. Надеть шляпу сразу на голову:
   /item replace entity @p armor.head with minecraft:carved_pumpkin[minecraft:custom_model_data=X]

Примеры популярных шляп:
  * 1  - Кошачьи ушки:          /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=1]
  * 2  - Ковбойская шляпа:      /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=2]
  * 16 - Капюшон Альтаира:      /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=16]
  * 26 - Шлем Довакина:         /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=26]
  * 28 - Шапка-ушанка:          /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=28]
  * 31 - Противогаз:            /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=31]
  * 34 - Маска Иноске:          /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=34]
  * 35 - Кепка Джотаро:         /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=35]
  * 42 - Шляпа Луффи:           /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=42]
  * 43 - Шляпа Мегумин:         /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=43]
  * 44 - Хацунэ Мику:           /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=44]
  * 48 - Повязка Наруто:        /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=48]
  * 57 - Шлем Солера (Солнце):  /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=57]
  * 69 - Маска Крик (Ghostface):/give @p minecraft:carved_pumpkin[minecraft:custom_model_data=69]
  * 70 - Майкл Майерс:          /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=70]
  * 76 - Глаза Херобрина:       /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=76]
  * 77 - Шемаг (Арафатка):      /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=77]

-----------------------------------------------------
[ ТЕХНИЧЕСКИЕ ДЕТАЛИ ]
-----------------------------------------------------
- pack_format: 34 (1.21) с поддержкой форматов 34-46 (включая 1.21.4+)
- Атлас текстур: assets/minecraft/atlases/blocks.json настроен на автоматическую сшивку textures/item/
- Двойная привязка: поддержка старых версий (models/item/carved_pumpkin.json) и новых (items/carved_pumpkin.json)
- Прозрачный pumpkinblur.png убирает черное ограничение обзора тыквы.
