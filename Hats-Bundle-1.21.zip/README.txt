=====================================================
          Hats Bundle - Adapted for Minecraft 1.21
=====================================================

Автор оригинальных моделей: Larkyy
Адаптация под Minecraft Java 1.21 (Paper / Purpur / Vanilla)

[ УСТАНОВКА ]

1. Установка для клиента:
   - Поместите папку "Hats-Bundle-1.21" или архив "Hats-Bundle-1.21.zip" в папку .minecraft/resourcepacks/
   - Включите ресурс-пак в настройках игры (Настройки -> Наборы ресурсов).

2. Установка на сервер (Server Resource Pack):
   - Загрузите архив "Hats-Bundle-1.21.zip" на хостинг ресурс-паков (например, mc-packs.net, GitHub Releases или свой HTTP-сервер).
   - В файле server.properties укажите прямую ссылку:
     resource-pack=https://your-host.com/Hats-Bundle-1.21.zip
     resource-pack-sha1=<SHA1_ХЭШ_АРХИВА>

-----------------------------------------------------
[ СПИСОК ШЛЯП И ИДЕНТИФИКАТОРЫ (CustomModelData) ]
-----------------------------------------------------

  ID  | Английское название | Русское название      | Модель
 -----+---------------------+-----------------------+-------------------------
   1  | Cat Ears Hat        | Кошачьи ушки          | hats:cat_ears_hat
   2  | Cowboy Hat          | Ковбойская шляпа      | hats:cowboy_hat
   3  | Crown Hat 1         | Королевская корона 1  | hats:crown_hat1
   4  | Fox Hat             | Шапка лисы            | hats:fox_hat
   5  | Gentleman Hat       | Шляпа джентльмена     | hats:gentleman_hat
   6  | Golden Crown        | Золотая корона        | hats:golden_crown
   7  | Halo Hat            | Нимб ангела           | hats:halo_hat
   8  | Horns Hat           | Рога демона           | hats:horns_hat
   9  | Iron Crown          | Железная корона       | hats:iron_crown
  10  | Mafia Hat           | Шляпа мафии           | hats:mafia_hat
  11  | Pirate Hat          | Пиратская шляпа       | hats:pirate_hat
  12  | Santa Hat           | Новогодняя шапка      | hats:santa_hat
  13  | Sombrero Hat        | Мексиканское сомбреро | hats:sombrero_hat

-----------------------------------------------------
[ КОМАНДЫ ДЛЯ MINECRAFT 1.21 ]
-----------------------------------------------------

В Minecraft 1.20.5+ и 1.21 синтаксис NBT-тегов ({CustomModelData:X}) был заменен на систему компонентов ([minecraft:custom_model_data=X]).

1. Получить шляпу в инвентарь:
   /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=1]
   (замените 1 на нужное значение от 1 до 13)

2. Надеть шляпу сразу на голову игрока:
   /item replace entity @p armor.head with minecraft:carved_pumpkin[minecraft:custom_model_data=1]

Примеры для всех 13 шляп:
  1. Кошачьи ушки:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=1]
  2. Ковбойская шляпа:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=2]
  3. Королевская корона 1:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=3]
  4. Шапка лисы:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=4]
  5. Шляпа джентльмена:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=5]
  6. Золотая корона:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=6]
  7. Нимб ангела:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=7]
  8. Рога демона:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=8]
  9. Железная корона:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=9]
 10. Шляпа мафии:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=10]
 11. Пиратская шляпа:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=11]
 12. Новогодняя шапка:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=12]
 13. Мексиканское сомбреро:
     /give @p minecraft:carved_pumpkin[minecraft:custom_model_data=13]

-----------------------------------------------------
[ ТЕХНИЧЕСКИЕ ИЗМЕНЕНИЯ ]
-----------------------------------------------------
- pack_format обновлен до 34 (Minecraft 1.21 - 1.21.1) с поддержкой форматов 34-46 (включая 1.21.2 - 1.21.4).
- Создана двойная привязка моделей:
  * assets/minecraft/models/item/carved_pumpkin.json (overrides для 1.21.0 - 1.21.1)
  * assets/minecraft/items/carved_pumpkin.json (range_dispatch для 1.21.2 - 1.21.4+)
- Исправлены пути к текстурам: текстуры перенесены в assets/hats/textures/item/ с идентификатором "hats:item/*" для полной совместимости с атласом текстур Minecraft 1.21 (blocks.json).
- Исправлена критическая ошибка неверного родителя ("parent": "pirate_hat" и "parent": "santa_hat"), приводившая к сбою загрузки моделей.
- Сохранен прозрачный оверлей pumpkinblur.png, отключающий затемнение экрана тыквы.
- Исходные Blockbench-проекты сохранены в папке files/.

# MVe7RZ97Ir0CkD8jYC17ONyiiNhKhj6sCFwpoiHacrodRmRJq2d7aL52LHsPTL42+d08EAPgFGH+dIEwHS1MyORv3F2d16vnmK9j8Y28RPY=

