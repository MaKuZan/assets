Installation:

Put the "Hats Bundle - Resource Pack" into your Resource Packs folder.
Enabled the resource pack in minecraft.

How to get a hat:

/minecraft:give @p minecraft:carved_pumpkin{CustomModelData:1}
The model data value is from 1 to 13
# MVe7RZ97Ir0CkD8jYC17ONyiiNhKhj6sCFwpoiHacrodRmRJq2d7aL52LHsPTL42+d08EAPgFGH+dIEwHS1MyORv3F2d16vnmK9j8Y28RPY=